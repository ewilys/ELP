package tc.elp.java.datastructures;

import java.lang.Exception; 

public class EmptyStackException extends Exception{}
